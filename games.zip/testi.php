<?php
require_once ("header.php");
$query="SELECT * from testimonials";
$data_tes=db::getRecords($query);
?>

<!-- breadcrumbs area start -->
<div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs_text text-center">
                    <h1>Testimonails</h1>
                    <ul class="d-flex justify-content-center">
                        <li><a href="index.php">Home </a></li>
                        <li> <span>//</span></li>
                        <li>Testimonails</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumbs area end -->
<!-- testimonial section start -->
    <section class="testimonial_section wow fadeInUp" data-bgimg="assets/img/others/testimonial-bg-fullwidth.webp"
        data-wow-delay="0.1s" data-wow-duration="1.1s">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title mb-60">
                        <h2>What streamers say <br>
                            ABOUT <span>LFGs.</span></h2>
                    </div>
                    <div class="testimonial_inner slick__activation slick_navigation" data-slick='{
                        "slidesToShow": 1,
                        "slidesToScroll": 1,
                        "arrows": true,
                        "dots": false,
                        "autoplay": false,
                        "speed": 300,
                        "infinite": true ,  
                        "responsive":[  
                        {"breakpoint":576, "settings": { "slidesToShow": 1 } }  
                        ]                                                     
                    }' data-bgimg="assets/img/bg/testimonial-bg.webp">
                        <?php
                            if($data_tes) {
                                foreach($data_tes as $tes) {
                            ?>
                        <div class="testimonial_list d-flex align-items-center">
                            <div class="testimonial_thumb">
                                <img width="270" height="319" src="admin/uploads/<?php echo $tes['image']; ?>" alt="">
                            </div>
                            <div class="testimonial_content">
                                <div class="testimonial_desc">
                                    <p><?php echo $tes['dcp']; ?></p>
                                </div>
                                <div class="testimonial_author">
                                    <h3><?php echo $tes['name'];?></h3>
                                    <span><?php echo $tes['designation']; ?></span>
                                </div>
                            </div>
                        </div>
                        <?php
                                }
                            }
                            ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- testimonial section end -->
<?php
require_once ("footer.php");
?>