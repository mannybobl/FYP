<?php
require_once ("header.php");
?>
<style>
::placeholder {
    color: white;
}
</style>
<!-- breadcrumbs area start -->
<div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs_text text-center">
                    <h1>Create Post</h1>
                    <ul class="d-flex justify-content-center">
                        <li><a href="index.php">Home </a></li>
                        <li> <span>//</span></li>
                        <li>Create Post</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumbs area end -->
<!-- page wrapper start -->
<div class="page_wrapper">

    <!-- contact section start -->
    <div class="gaming_page_inner">
        <div class="section_title text-center wow fadeInUp mb-60" data-wow-delay="0.1s" data-wow-duration="1.1s">
            <h2>Our Games</h2>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    <div class="popular_gaming_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <a href="game-details.html"><img width="570" height="330" src="assets/img/others/call.jpg"
                                alt=""></a>
                        <div class="gaming_details_btn">
                            <a class="btn btn-link" href="create-post1.php">Call of duty</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="popular_gaming_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <a href="game-details.html"><img width="570" height="330" src="assets/img/others/OIP.jpg"
                                alt=""></a>
                        <div class="gaming_details_btn">
                            <a class="btn btn-link" href="create-post1.php">Valorant</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="popular_gaming_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <a href="game-details.html"><img width="570" height="330" src="assets/img/others/download.jpg"
                                alt=""></a>
                        <div class="gaming_details_btn">
                            <a class="btn btn-link" href="create-post1.php">Overwatch</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="popular_gaming_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <a href="game-details.html"><img width="570" height="330"
                                src="assets/img/others/download (2).jpg" alt=""></a>
                        <div class="gaming_details_btn">
                            <a class="btn btn-link" href="create-post1.php">Destiny 2</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="popular_gaming_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <a href="game-details.html"><img width="570" height="330" src="assets/img/others/OIP (2).jpg"
                                alt=""></a>
                        <div class="gaming_details_btn">
                            <a class="btn btn-link" href="create-post1.php">Rainbow Six siege</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="popular_gaming_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <a href="game-details.html"><img width="570" height="330"
                                src="assets/img/others/download (3).jpg" alt=""></a>
                        <div class="gaming_details_btn">
                            <a class="btn btn-link" href="create-post1.php">League Legends</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="popular_gaming_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <a href="game-details.html"><img width="570" height="330"
                                src="assets/img/others/download (4).jpg" alt=""></a>
                        <div class="gaming_details_btn">
                            <a class="btn btn-link" href="create-post1.php">Apex legends</a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="popular_gaming_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <a href="game-details.html"><img width="570" height="330" src="assets/img/others/R (1).jpg"
                                alt=""></a>
                        <div class="gaming_details_btn">
                            <a class="btn btn-link" href="create-post1.php">Fortnite</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- contact section end -->

</div>
<!-- page wrapper end -->

<?php
require_once ("footer.php");
?>