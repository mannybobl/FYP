<?php
require_once ("header.php");
?>



    <!-- breadcrumbs area start -->
    <div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumbs_text text-center">
                        <h1>about us</h1>
                        <ul class="d-flex justify-content-center">
                            <li><a href="index.html">Home </a></li>
                            <li> <span>//</span></li>
                            <li>  about us</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumbs area end -->

    <!-- page wrapper start -->
    <div class="page_wrapper">

        <!-- about section start -->
        <section class="about_section">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="about_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                            <img width="550" height="550" src="assets/img/others/about-thumb.webp" alt="">
                            <div class="about_video_btn">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about_sidebar wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1.2s">
                            <div class="about_title">
                                <h5>ABOUT</h5>
                                <h2>THE GAMERS LFG</h2>
                            </div>
                            <div class="about_desc">
                                <p>"Hey there! I'm CDLshaf, an avid gamer with a passion for fostering inclusive gaming communities. Whether it's teaming up for epic quests or just hanging out in-game, I believe in creating spaces where everyone feels welcome and valued. With a commitment to tackling cyberbullying, loneliness, and promoting gender diversity, I'm here to connect with like-minded gamers who share the same vision. Let's embark on exciting adventures together and make gaming a more inclusive and enjoyable experience for all!"</p>
                            </div>
                            <div class="about_btn">
                                <a class="btn btn-link wow" href="all-game.php">Play Now <img width="20" height="20" src="assets/img/icon/arrrow-icon.webp" alt=""> </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about section end -->

        <!-- gaming update section start -->
        <section class="gaming_update_section">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="gaming_update_inner d-flex justify-content-between align-items-center" data-bgimg="assets/img/bg/gaming-update.webp">
                            <div class="gaming_update_text">
                                <h2>Connect with us <br>
                                    for gamING update.</h2>
                            </div>
                            <div class="gaming_update_btn">
                                <a class="btn btn-link" href="#">CONNECT NOW <img width="20" height="20" src="assets/img/icon/arrrow-icon.webp" alt=""> </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- gaming update section end -->

    </div>
    <!-- page wrapper end -->
<?php
require_once ("footer.php");
?>

