<?php
require_once ("header.php");
?>
<!-- breadcrumbs area start -->
<div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs_text text-center">
                    <h1>Sign in</h1>
                    <ul class="d-flex justify-content-center">
                        <li><a href="index.php">Home </a></li>
                        <li> <span>//</span></li>
                        <li> Sign In</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumbs area end -->
<!-- page wrapper start -->
<div class="page_wrapper">

    <!-- contact section start -->
    <section class="contact_page_section mb-140">
        <div class="container">
            <div class="row justify-content-between align-items-center mb-n50">
                <div class="col-lg-6 col-md-8 col-12 mx-auto mb-50">
                    <img width="550" height="550" src="assets/img/others/about-thumb.webp" alt="">
                </div>
                <div class="col-lg-5 col-md-8 col-12 mx-auto mb-50">
                    <div class="section_title text-center mb-60">
                        <h2>Sign in</h2>
                    </div>
                    <form action="action.php" method="POST">
                        <div class="form_input">
                            <input name="email" placeholder="Email" type="email">
                        </div>
                        <div class="form_input">
                            <input name="pwd" placeholder="Password" type="password">
                        </div>
                        <div class="form_input_btn text-center mb-40">
                            <button type="submit" name="login" class="btn btn-link">Sign in<img width="20" height="20"
                                    src="assets/img/icon/arrrow-icon.webp" alt=""></button>
                        </div>
                        <p class="text-center">Don't have any account, <a href="registration.php">Signup here</a></p>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- contact section end -->

</div>
<!-- page wrapper end -->
<?php
require_once ("footer.php");
?>