<?php
session_start();
require_once("admin/database.php");

// Register user
if(isset($_POST['register'])) {
$name = ($_POST['name']);
$email = ($_POST['email']);
$pwd = ($_POST['pwd']);
$pwd_2 = ($_POST['pwd_2']);
$check_query = "SELECT * FROM  users WHERE email = '$email'";
$result =db::getRecord($check_query);
if($result > 0) {
echo "<script>
alert('Email already exists.')
</script>";
echo "<script>
window.location = 'registration.php';
</script>";
}
if($pwd == $pwd_2) {
$userinsert = "INSERT INTO `users`(`name`, `email`, `password`,`confirm_password`) VALUES
('$name','$email','$pwd','$pwd_2')";
db::query($userinsert);
echo "<script>
alert('User Registered.')
</script>";
echo "<script>
window.location = 'login.php';
</script>";
} else {
echo "<script>
alert('Password and Confirm password do not match.')
</script>";
echo "<script>
window.location = 'registration.php';
</script>";
}
}
// Login User
if(isset($_POST['login'])) {
$email = $_POST['email'];
$pwd = $_POST['pwd'];
$query = "SELECT * FROM users WHERE email='$email'AND password='$pwd'";
$rec = db::getRecord($query);
if ($rec) {
    $_SESSION['id']=$rec['id'];
header("location:add_game.php");

exit();
} else {
echo "<script>
alert('Email and password does not match.')
</script>";
header('location:login.php');
exit();
}
}

//add post
if (isset($_POST['add_post'])) {
    $person_need =$_POST['person_need'];
    $post_name =$_POST['post_name'];
    $date =$_POST['date'];
    $time =$_POST['time'];
    $game_id =$_POST['game_id'];
    $user_id =$_POST['user_id'];
    $query_insert = "INSERT INTO `game_post` (`person_need`, `post_name`, `date`, `time`,`user_id`, `game_id`) VALUES ('$person_need ','$post_name','$date','$time','$user_id','$game_id')";
    db::query($query_insert);
    echo "<script>
    location = 'add_game.php'
    </script>";
    }

// addpost
    if (isset($_POST['addpost'])) {
        $name =$_POST['name'];
        $post_id =$_POST['post_id'];
        $maicrophone =$_POST['microphone'];
        $future =$_POST['future'];
        $paltform =$_POST['platform'];
        $con_message =$_POST['con_message'];
        $query_insert = "INSERT INTO `en_rolluser` (`post_id`, `name`, `microphone`, `future`, `platform`, `con_message`) VALUES ('$post_id ','$name','$microphone','$future','$platform','$con_message')";
        db::query($query_insert);
        echo "<script>
        location = 'all-game.php'
        </script>";
        }
        if(isset($_GET['logout'])){
            unset($_SESSION['id']);
            session_destroy();
            echo "<script>location='index.php'</script>";
        }
?>