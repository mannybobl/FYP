<?php
require_once ("header.php");
?>
<style>
   a, button, img, input, span {
    color: white;
    padding-top:5px;
}
.form_input input[type="time"]::-webkit-calendar-picker-indicator {
    filter: invert(1);
}
.form_input input[type="date"]::-webkit-calendar-picker-indicator {
    filter: invert(1);
}
</style>
<!-- breadcrumbs area start -->
<div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs_text text-center">
                    <h1>Our Post</h1>
                    <ul class="d-flex justify-content-center">
                        <li><a href="index.php">Home </a></li>
                        <li> <span>//</span></li>
                        <li>Our Post</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumbs area end -->
<!-- page wrapper start -->
<div class="page_wrapper">

    <!-- contact section start -->
    <div class="gaming_page_inner">
        <div class="container mt-5 pt-5">
            <div class="row">
                <div class="col-lg-12 mb-50">
                    <div class="form_input">
                        <input name="need" placeholder="Person Need" type="text">
                    </div>
                    <div class="form_input">
                        <input name="paerson" placeholder="Post Name" type="text">
                    </div>
                    <div class="form_input">
                        <input name="date" placeholder="Date" type="date">
                    </div>
                    <div class="form_input">
                        <input name="time" placeholder="time" type="time">
                    </div>
                    <div class="sing_up_btn">
                        <a class="btn btn-link" href="#">Submit<img width="15" height="15" src="assets/img/icon/arrrow-icon2.webp" alt=""> </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- contact section end -->

</div>
<!-- page wrapper end -->

<?php
require_once ("footer.php");
?>