<?php
require_once ("header.php");
$id=$_GET['id'];
$query="SELECT * from game_post WHERE user_id='$user_id'";
$recs=db::getRecords($query);
?>
<style>
    .form-select{
            color: white !important;
    }
    option{
        background-color:#0a071c !IMportant;
    }
</style>
<div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs_text text-center">
                    <h1>View Post</h1>
                    <ul class="d-flex justify-content-center">
                        <li><a href="index.php">Home </a></li>
                        <li> <span>//</span></li>
                        <li>View Post</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="gaming_page_inner">
    <div class="container ">
        <div class="row">
            <div class="col-lg-12 mb-50">
                <table class="table text-white text-center">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">person Need</th>
                            <th scope="col">Post Name</th>
                            <th scope="col">Date</th>
                            <th scope="col">Time</th>
                            <th scope="col">Applied User</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
               if ($recs) {
                $i = 0;
                foreach ($recs as $rec) {
                    $i++;
                    ?>
                        <tr>
                            <th scope="row"><?php echo $i ?></th>
                            <td><?php echo $rec['person_need'] ?></td>
                            <td><?php echo $rec['post_name'] ?></td>
                            <td><?php echo $rec['date'] ?></td>
                            <td><?php echo $rec['time'] ?></td>
                            <td>
                                <a href="applied_user.php?id=<?php  echo $rec['id']; ?>" class="btn btn-link insert" style="padding: 10px 30px 10px 30px;">
                                    Applied User
                                </a>
                            </td>
                        </tr>
                        <?php
                }
            }
            ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>




<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $(document).on('click', '.insert', function() {
        var campaigns = $(this).val();
        // alert("Campaign ID: " + campaigns);
        $('#campaigns_id').val(campaigns);
    });
});
</script>