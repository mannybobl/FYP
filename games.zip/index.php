<?php
require_once ("header.php");

$query="SELECT * from banner ";
$banner=db::getRecord($query);

$query="SELECT * from testimonials";
$data_tes=db::getRecords($query);

$query="SELECT * from about";
$about=db::getRecord($query);

$query="SELECT * from game_services";
$recs=db::getRecords($query);

?>

<!-- page wrapper start -->
<div class="page_wrapper">

    <!--slide banner section start-->
    <section class="hero_banner_section d-flex align-items-center mb-130" data-bgimg="assets/img/bg/gaming-bg1.webp">
        <div class="container">
            <div class="hero_banner_inner">
                <div class="row align-items-center">
                    <div class="col-12">
                        <div class="hero_content">
                            <h1 class="wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s" style="font-family: Exo, sans-serif">
                                <?php echo $banner['heading']; ?></h1>
                            <p class="wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1.2s">
                                <?php echo $banner['dcp']; ?></p>
                            <a class="btn btn-link wow fadeInUp" data-wow-delay="0.3s" data-wow-duration="1.3s"
                                href="all-game.php" style="padding:15px;padding-left: 20px; padding-right:20px;">Play
                                Now </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero_position_img">
            <!-- <img width="926" height="772" src="admin/uploads/<?php  echo $banner['image'] ?>" alt=""> -->
        </div>
    </section>
    <!--slider area end-->

    <!-- about section start -->
    <section class="about_section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <img width="550" height="550" src="admin/uploads/<?php echo $about['image'] ?>" alt="">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about_sidebar wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1.2s">
                        <div class="about_title">
                            <h5>ABOUT</h5>
                            <h2><?php  echo $about['heading'] ?></h2>
                        </div>
                        <div class="about_desc">
                            <p><?php  echo $about['dcp'] ?></p>
                        </div>
                        <div class="about_btn">
                            <a class="btn btn-link wow" href="all-game.php"
                                style="padding:15px;padding-left: 20px; padding-right:20px;">Play Now </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- about section end -->
    <section class="blog_page_section mb-140">
        <div class="section_title text-center wow fadeInUp mb-60" data-wow-delay="0.1s" data-wow-duration="1.1s">
            <h2>Games</h2>
        </div>
        <div class="container">
            <div class="row">
                <?php
		if($recs)
		{
			foreach($recs as $rec)
			{
				?>
                <div class="col-lg-4 col-md-6">
                    <div class="popular_gaming_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <a href="viewpost.php?id=<?php  echo $rec['id'] ?>"><img width="570" height="330"
                                src="admin/uploads/<?php  echo $rec['image'] ?>" alt=""></a>
                        <div class="gaming_details_btn">
                            <a class="btn btn-link wow" href="viewpost.php?id=<?php  echo $rec['id'] ?>"
                                style="padding:15px;padding-left: 20px; padding-right:20px;"><?php  echo $rec['heading'] ?>
                            </a>
                        </div>
                    </div>
                </div>
                <?php
			}
		}
		?>
                
            </div>
        </div>
    </section>
    <!-- testimonial section start -->
    <section class="testimonial_section wow fadeInUp" data-bgimg="assets/img/others/testimonial-bg-fullwidth.webp"
        data-wow-delay="0.1s" data-wow-duration="1.1s">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title mb-60">
                        <h2>What people’s say <br>
                            ABOUT <span>game studio.</span></h2>
                    </div>
                    <div class="testimonial_inner slick__activation slick_navigation" data-slick='{
                        "slidesToShow": 1,
                        "slidesToScroll": 1,
                        "arrows": true,
                        "dots": false,
                        "autoplay": false,
                        "speed": 300,
                        "infinite": true ,  
                        "responsive":[  
                        {"breakpoint":576, "settings": { "slidesToShow": 1 } }  
                        ]                                                     
                    }' data-bgimg="assets/img/bg/testimonial-bg.webp">
                        <?php
                            if($data_tes) {
                                foreach($data_tes as $tes) {
                            ?>
                        <div class="testimonial_list d-flex align-items-center">
                            <div class="testimonial_thumb">
                                <img width="270" height="319" src="admin/uploads/<?php echo $tes['image']; ?>" alt="">
                            </div>
                            <div class="testimonial_content">
                                <div class="testimonial_desc">
                                    <p><?php echo $tes['dcp']; ?></p>
                                </div>
                                <div class="testimonial_author">
                                    <h3><?php echo $tes['name'];?></h3>
                                    <span><?php echo $tes['designation']; ?></span>
                                </div>
                            </div>
                        </div>
                        <?php
                                }
                            }
                            ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- testimonial section end -->


    <!-- gaming update section start -->
    <section class="gaming_update_section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="gaming_update_inner d-flex justify-content-between align-items-center"
                        style="background: white;border-radius: 70px;">
                        <div class="gaming_update_text">
                            <h2 style="color: black;">Connect with us <br>

                                for gamING update.</h2>
                        </div>
                        <div class="gaming_update_btn">
                            <a class="btn btn-link" href="contact.php"
                                style="padding:20px;padding-left: 20px; padding-right:20px;background:black !important; color:white !important;">CONNECT
                                NOW </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- gaming update section end -->

</div>
<!-- page wrapper end -->

<?php
require_once ("footer.php");
?>