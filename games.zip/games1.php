<?php
require_once ("header.php");

$query="SELECT * from game_services";
$recs=db::getRecords($query);
?>
<style>
a,
button,
img,
input,
span {
    color: white;
    padding-top: 5px;
}

.form_input input[type="time"]::-webkit-calendar-picker-indicator {
    filter: invert(1);
}

.form_input input[type="date"]::-webkit-calendar-picker-indicator {
    filter: invert(1);
}
</style>
<!-- breadcrumbs area start -->
<div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs_text text-center">
                    <h1>Play with us</h1>
                    <ul class="d-flex justify-content-center">
                        <li><a href="index.php">Home </a></li>
                        <li> <span>//</span></li>
                        <li>Play with us</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumbs area end -->
<!-- page wrapper start -->
<div class="page_wrapper">

    <!-- contact section start -->
    <div class="gaming_page_inner">
        <div class="container mt-5 pt-5">
            <div class="row">
                <div class="col-lg-12 mb-50">
                    <div class="form_input">
                        <input name="name" placeholder="Username" type="text">
                    </div>
                    <select class="form-select w-100 mb-4" aria-label="Default select example">
                        <option selected>I have a microphone</option>
                        <option value="1">Yes</option>
                        <option value="2">No</option>

                    </select>
                    <select class="form-select w-100 mb-4" aria-label="Default select example">
                        <option selected>Want to play now in future</option>
                        <option value="1">Now</option>
                        <option value="2">Scheduled</option>
                    </select>
                    <select class="form-select w-100 mb-4" aria-label="Default select example">
                        <option selected>Play with all paltform?</option>
                        <option value="1">Cross</option>
                        <option value="2">Only on my platform</option>
                    </select>
                    <div class="form_input">
                        <div class="form_textarea">
                            <textarea name="con_message" placeholder="Write a review from here"></textarea>
                        </div>
                    </div>
                    <div class="sing_up_btn">
                        <a class="btn btn-link" href="#">submit<img width="15" height="15"
                                src="assets/img/icon/arrrow-icon2.webp" alt=""> </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- contact section end -->

    </div>
    <!-- page wrapper end -->

    <?php
require_once ("footer.php");
?>