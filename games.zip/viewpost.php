<?php
require_once ("header.php");
$id=$_GET['id'];
$query="SELECT * from game_post WHERE game_id='$id'";
$recs=db::getRecords($query);
?>
<style>
    .form-select{
            color: white !important;
    }
    option{
        background-color:#0a071c !IMportant;
    }
</style>
<div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs_text text-center">
                    <h1>Enroll Now</h1>
                    <ul class="d-flex justify-content-center">
                        <li><a href="index.php">Home </a></li>
                        <li> <span>//</span></li>
                        <li>Enroll Now</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="gaming_page_inner">
    <div class="container ">
        <div class="row">
            <div class="col-lg-12 mb-50">
                <table class="table text-white text-center">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">person Need</th>
                            <th scope="col">Post Name</th>
                            <th scope="col">Date</th>
                            <th scope="col">Time</th>
                            <th scope="col">Enrollment</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
               if ($recs) {
                $i = 0;
                foreach ($recs as $rec) {
                    $i++;
                    ?>
                        <tr>
                            <th scope="row"><?php echo $i ?></th>
                            <td><?php echo $rec['person_need'] ?></td>
                            <td><?php echo $rec['post_name'] ?></td>
                            <td><?php echo $rec['date'] ?></td>
                            <td><?php echo $rec['time'] ?></td>
                            <td><button type="button" value="<?php echo $rec['id'] ?>" class="btn btn-link insert" style="padding: 10px 30px 10px 30px;"
                                    data-bs-toggle="modal" data-bs-target="#exampleModal">
                                    Enroll
                                </button></td>
                        </tr>
                        <?php
                }
            }
            ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content" style="background: #0a071c;box-shadow: 0px 0px 20px 0px lightgray;border-radius: 20px;">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="gaming_page_inner">
                    <div class="container">
                        <form action="action.php" method="POST">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form_input">
                                        <input name="name" placeholder="Username" type="text">
                                    </div>
                                    <input type="hidden" name="post_id" id="campaigns_id" value="">
                                    <select class="form-select w-100 mb-4" aria-label="Default select example"
                                        name="microphone">
                                        <option selected>I have a microphone</option>
                                        <option value="Yes">Yes</option>
                                        <option value="No">No</option>

                                    </select>
                                    <select class="form-select w-100 mb-4" aria-label="Default select example"
                                        name="future">
                                        <option selected>Want to play now in future</option>
                                        <option value="Now">Now</option>
                                        <option value="Scheduled">Scheduled</option>
                                    </select>
                                    <select class="form-select w-100 mb-4" aria-label="Default select example"
                                        name="platorm">
                                        <option selected>Play with all platform?</option>
                                        <option value="Cross">Cross</option>
                                        <option value="Only on my platform">Only on my platform</option>
                                    </select>
                                    <div class="form_input">
                                        <div class="form_textarea">
                                            <textarea name="con_message"
                                                placeholder="Comment"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" name="addpost" class="btn btn-link" style="padding: 10px 30px 10px 30px;">Add</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $(document).on('click', '.insert', function() {
        var campaigns = $(this).val();
        // alert("Campaign ID: " + campaigns);
        $('#campaigns_id').val(campaigns);
    });
});
</script>