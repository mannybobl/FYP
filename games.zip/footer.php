<?php
require_once("admin/database.php");

$query="SELECT * from logo";
$logo=db::getRecord($query);
?>
<!--footer area start-->
<footer class="footer_widgets">
    <div class="main_footer">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="main_footer_inner d-flex">
                        <div class="footer_widget_list">
                            <div class="footer_logo">
                                <a class="sticky_none" href="index.php">
                                <img class="logo-dark" src="admin/uploads/<?php  echo $logo['image'] ?>">
                            </a>
                            </div>
                            <div class="footer_contact_desc">
                                
                            </div>
                            <div class="footer_social">
                            </div>
                        </div>
                        <div class="footer_widget_list contact">
                            <h3>Contact</h3>
                            <div class="footer_contact_info">
                                <div class="footer_contact_info_list">
                                    <span>Location:</span>
                                    <p>Birmingham Aston 
                                         </p>
                                </div>
                                <div class="footer_contact_info_list">
                                    <span>Phone:</span>
                                    <p><a href="#">1234 567 890</a></p>
                                </div>
                            </div>
                        </div>
                        <div class="footer_widget_list footer_list_menu">
                            <h3>Content</h3>
                            <div class="footer_menu">
                                <ul>
                                    <li><a href="index.php"> Home</a></li>
                                    <li><a href="about.php">About</a></li>
                                    <li><a href="games.php">Games</a></li>
                                    <li><a href="testi.php">Reviews</a></li>
                                    <li><a href="contact.php">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer_bottom">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="footer_bottom_inner d-flex justify-content-between">
                        <div class="copyright_right">
                            <p><?php echo $logo['dcp']; ?></p>
                        </div>

                        <div class="scroll__top_icon">
                            <a id="scroll-top" href="#"><img aria-label="scroll-top" width="46" height="40"
                                    src="assets/img/icon/scroll-top.webp" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--footer area end-->


<!-- JS
============================================ -->
<!--modernizr min js here-->
<script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>

<!-- Vendor JS -->
<script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
<script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
<script src="assets/js/vendor/popper.js"></script>
<script src="assets/js/vendor/bootstrap.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="assets/js/jquery.nice-select.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script src="assets/js/jquery.counterup.min.js"></script>
<script src="assets/js/jquery-waypoints.js"></script>

<!-- Main JS -->
<script src="assets/js/main.js"></script>


</body>

</html>