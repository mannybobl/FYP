<?php

require_once ("header.php");

$query="SELECT * from game_services";
$recs=db::getRecords($query);
?>
<!-- breadcrumbs area start -->
<div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs_text text-center">
                    <h1>Games</h1>
                    <ul class="d-flex justify-content-center">
                        <li><a href="index.php">Home </a></li>
                        <li> <span>//</span></li>
                        <li>Games</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumbs area end -->

<!-- page wrapper start -->
<div class="page_wrapper">


    <section class="blog_page_section mb-140">
        <div class="section_title text-center wow fadeInUp mb-60" data-wow-delay="0.1s" data-wow-duration="1.1s">
            <h2>Games</h2>
        </div>
        <div class="container">
            <div class="row">
                <?php
                if($recs)
                {
                foreach($recs as $rec)
                {
                ?>
                <div class="col-lg-4 col-md-6">
                    <div class="popular_gaming_thumb wow fadeInUp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                        <a href="create-post1.php?id=<?php  echo $rec['id'] ?>"><img width="570" height="330"
                                src="admin/uploads/<?php  echo $rec['image'] ?>" alt=""></a>
                        <div class="gaming_details_btn">
                            <a class="btn btn-link"
                                href="create-post1.php?id=<?php  echo $rec['id'] ?>">Add Post</a>
                        </div>
                    </div>
                </div>
                <?php
			}
		}
		?>
            </div>
    </section>
    <!-- gaming update section start -->
    <section class="gaming_update_section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="gaming_update_inner d-flex justify-content-between align-items-center"
                        data-bgimg="assets/img/bg/gaming-update.webp">
                        <div class="gaming_update_text">
                            <h2>Connect with us <br>
                                for gamING update.</h2>
                        </div>
                        <div class="gaming_update_btn">
                            <a class="btn btn-link" href="contact.php">CONNECT NOW <img width="20" height="20"
                                    src="assets/img/icon/arrrow-icon.webp" alt=""> </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- gaming update section end -->

</div>
<!-- page wrapper end -->

<?php
require_once ("footer.php");
?>