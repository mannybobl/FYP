<?php
session_start();
require_once ("header.php");
require_once("admin/database.php");
$id=$_GET['id'];
?>
<style>
a,
button,
img,
input,
span {
    color: white;
    padding-top: 5px;
}

.form_input input[type="time"]::-webkit-calendar-picker-indicator {
    filter: invert(1);
}

.form_input input[type="date"]::-webkit-calendar-picker-indicator {
    filter: invert(1);
}
</style>
<!-- breadcrumbs area start -->
<div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumbs_text text-center">
                    <h1>Create Post</h1>
                    <ul class="d-flex justify-content-center">
                        <li><a href="index.php">Home </a></li>
                        <li> <span>//</span></li>
                        <li>Create Post</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumbs area end -->
<!-- page wrapper start -->
<div class="page_wrapper">

    <!-- contact section start -->
    <div class="gaming_page_inner">
        <div class="container mt-5 pt-5">
            <div class="row">
                <div class="col-lg-12 mb-50">
                    <form action="action.php" method="POST">
                        <div class="form_input">
                            <input name="person_need" placeholder="Person Need" type="text">
                        </div>
                        <input type="hidden" name="game_id" value="<?php  echo $id ?>">
                        <input type="hidden" name="user_id" value="<?php  echo $_SESSION['id']?>">
                        <div class="form_input">
                            <input name="post_name" placeholder="Post Name" type="text">
                        </div>
                        <div class="form_input">
                            <input name="date" placeholder="Date" type="date">
                        </div>
                        <div class="form_input">
                            <input name="time" placeholder="time" type="time">
                        </div>
                        <div class="sing_up_btn">
                            <button class="btn btn-link" name="add_post">Add<img width="15" height="15"
                                    src="assets/img/icon/arrrow-icon2.webp" alt=""> </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- contact section end -->

</div>
<!-- page wrapper end -->

<?php
require_once ("footer.php");
?>