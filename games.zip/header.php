<?php
error_reporting(0);
session_start();
if(isset($_SESSION['id'])){
    $user_id=$_SESSION['id'];
}
require_once("admin/database.php");
$query="SELECT * from logo ";
$logo=db::getRecord($query);
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Games</title>
    <meta name="description"
        content="Bonx is a terrific esports website template with a slick and modern look.  It’s a robust gaming HTML template for bloggers and online gamers who want to share their enthusiasm for games on the internet." />
    <meta name="keywords"
        content="	bootstrap, clean, esports, game, game portal, Game website, gamer, games, gaming, magazine, match, modern, online game, sport, sports">
    <meta name="author" content="Code Carnival">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Add site Favicon -->
    <link rel="shortcut icon" href="admin/uploads/<?php  echo $logo['image'] ?>" type="image/png">

    <!-- CSS 
        ========================= -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Exo:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;family=Metal+Mania&amp;display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/slick.css">
    <link rel="stylesheet" href="assets/css/icofont.min.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/nice-select.css">
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    <!-- Main Style CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
</head>
<style>
    .dropbtn {
  background-color: #04AA6D;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
</style>

<body class="body__bg" data-bgimg="assets/img/bg/body-bg.webp">

    <!--header area start-->
    <header class="header_section header_transparent sticky-header">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="main_header d-flex justify-content-between align-items-center">
                        <div class="header_logo">
                            <a class="sticky_none" href="index.php">
                                <img class="logo-dark" src="admin/uploads/<?php  echo $logo['image'] ?>">
                            </a>
                        </div>
                        <!--main menu start-->
                        <div class="main_menu d-none d-lg-block">
                            <nav>
                                <ul class="d-flex">
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about.php">About</a>
                                    </li>
                                    <li><a href="all-game.php">Games</a>
                                    </li>
                                    <li><a class="testimonials-link" href="testi.php">Testimonails</a>
                                    </li>
                                    <li><a href="contact.php">Contact</a></li>
                                </ul>
                            </nav>
                        </div>
                        <!--main menu end-->
                        <div class="header_right_sidebar d-flex align-items-center">
                            
                            <div class="sing_up_btn">
                                
                                <?php
                                if($user_id){
                                    
                                    ?>
                                    <div class="dropdown">
                              <button class="btn btn-link" >Dashboard</button>
                              <div class="dropdown-content">
                              <a href="add_game.php">Add Post</a>
                              <a href="new_post.php">View Post</a>
                                <a href="action.php?logout">Logout</a>
                                
                              </div>
                            </div>
                                    <?php
                                }
                                else
                                {
                                    echo '<a class="btn btn-link" href="login.php">Sign in</a>';
                                }
                                
                                ?>
                                
                            </div>
                            <div class="canvas_open">
                                <button type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasMenu"><i
                                        class="icofont-navigation-menu"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--header area end-->
    <!--offcanvas menu area start-->
    <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasMenu">
        <div class="offcanvas-header justify-content-end">
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <ul class="offcanvas_main_menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a>
                </li>
                <li><a href="post.php">post</a></li>
                <li><a href="all-game.php">Games</a>
                </li>
                <li><a href="blog-left-sidebar.php">Testimonails</a>
                </li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
            </li>
            </ul>
        </div>
    </div>
    <!--offcanvas menu area end-->