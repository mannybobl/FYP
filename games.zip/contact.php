<?php
require_once ("header.php");
?>
    <!-- breadcrumbs area start -->
    <div class="breadcrumbs_aree breadcrumbs_bg mb-140" data-bgimg="assets/img/bg/breadcrumbs-bg.webp">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="breadcrumbs_text text-center">
                        <h1>Contact us</h1>
                        <ul class="d-flex justify-content-center">
                            <li><a href="index.php">Home </a></li>
                            <li> <span>//</span></li>
                            <li>Contact</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- breadcrumbs area end -->
    <!-- page wrapper start -->
    <div class="page_wrapper">
    
        <!-- contact section start -->
        <section class="contact_page_section mb-140">
            <div class="container">
                <div class="contact_info_area">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="contact_info_list left wow fadeInUp" data-bgimg="assets/img/others/gaming-world-bg1.webp" data-wow-delay="0.1s" data-wow-duration="1.1s">
                                <div class="contact_info_thumb">
                                    <img width="115" height="115" src="assets/img/icon/email.webp" alt="">
                                </div>
                                <div class="contact_info_text">
                                    <h3>Email:</h3>
                                    <p>
                                        <a href="200159937@aston.ac.uk">200159937@aston.ac.uk</a>  <br>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="contact_info_list center wow fadeInUp" data-bgimg="assets/img/others/gaming-world-bg2.webp" data-wow-delay="0.2s" data-wow-duration="1.2s">
                                <div class="contact_info_thumb">
                                    <img width="115" height="115" src="assets/img/icon/location.webp" alt="">
                                </div>
                                <div class="contact_info_text">
                                    <h3>Location:</h3>
                                    <p>Birmingham
                                          Aston, B4 7ET</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-6">
                            <div class="contact_info_list right wow fadeInUp" data-bgimg="assets/img/others/gaming-world-bg3.webp" data-wow-delay="0.3s" data-wow-duration="1.3s">
                                <div class="contact_info_thumb">
                                    <img width="115" height="115" src="assets/img/icon/phone.webp" alt="">
                                </div>
                                <div class="contact_info_text">
                                    <h3>Phone:</h3>
                                    <p> 
                                        <a href="tel:123 456 789"> 123 456 789</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


    </div>
    <!-- page wrapper end -->

<?php
require_once ("footer.php");
?>