<?php
session_start();
require_once("database.php");
$db = db::open();
$datee = date("d-m-Y");
// all insertion code start
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $query="SELECT * FROM admin WHERE email='$email' AND password='$password'";
    $rec = db::getRecord($query);
    if ($rec != NULL) {
        $_SESSION['email'] = $_POST['email'];
        header('location:dashboard.php');
    } else {
        header('location:index.php');
    }
}
//update admin
if (isset($_POST['update'])) {
    $name = $_POST['name'];
    $password = $_POST['password'];
    if ($_FILES['doc_file']['name'] == "") {
        $sql2 = "UPDATE admin SET name='$name',password='$password'";
        $r = db::query($sql2);
        echo "
<script>location='profile.php?status=1'</script>";
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['doc_file']['name'];
        $file_loc = $_FILES['doc_file']['tmp_name'];
        $file_size = $_FILES['doc_file']['size'];
        $file_type = $_FILES['doc_file']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql2 = "UPDATE admin SET name='$name',password='$password',image='$final_file'";
        $r = db::query($sql2);
        echo "
<script>location='profile.php?status=1'</script>";

    }
}

//logout
if (isset($_GET['logout'])) {
    unset($_SESSION['email']);
    echo "
<script>location='index.php'</script>";
}

// update_logo
if (isset($_POST['update_logo'])) {
    $dcp = $db->real_escape_string($_POST['dcp']);
    $id = $db->real_escape_string($_POST['id']);

    if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE logo SET dcp='$dcp'";
        db::query($sql);
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE logo SET dcp='$dcp',image='$final_file' ";
        db::query($sql);
    }
    echo "
<script>location='logo.php'</script>";
}

// update_banner
if (isset($_POST['update_banner'])) {
    $heading = $db->real_escape_string($_POST['heading']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $id = $db->real_escape_string($_POST['id']);

    if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE banner SET dcp='$dcp',heading='$heading'";
        db::query($sql);
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE banner SET dcp='$dcp',heading='$heading',image='$final_file' ";
        db::query($sql);
    }
    echo "
<script>location='banner.php'</script>";
}

//update_about
if (isset($_POST['update_about'])) {
    $heading = $db->real_escape_string($_POST['heading']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $id = $db->real_escape_string($_POST['id']);
    
    if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE  about SET heading='$heading',dcp='$dcp' WHERE id='$id'";
        db::query($sql);
    } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE  about SET heading='$heading',dcp='$dcp',image='$final_file' WHERE id='$id'";
        echo db::query($sql);
    }
    echo "
<script>location='about.php'</script>";
}

//add_game_services
if (isset($_POST['add_services'])) {
$heading = $db->real_escape_string($_POST['heading']);

$file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
$file_loc = $_FILES['image']['tmp_name'];
$file_size = $_FILES['image']['size'];
$file_type = $_FILES['image']['type'];
$folder = "uploads/";
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);
$a = move_uploaded_file($file_loc, $folder . $final_file);
$query_insert = "INSERT INTO `game_services` (`heading`,`image`) VALUES ('$heading','$final_file')";
db::query($query_insert);
echo "
<script>
location = 'services.php'
</script>";
}

//game_services update
if (isset($_POST['update_game'])) {
$heading = $db->real_escape_string($_POST['heading']);
$id=$_POST['id'];

if ($_FILES['image']['name'] == "") {
$sql = "UPDATE game_services SET heading='$heading' WHERE id='$id'";
db::query($sql);
} else {
$file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
$file_loc = $_FILES['image']['tmp_name'];
$file_size = $_FILES['image']['size'];
$file_type = $_FILES['image']['type'];
$folder = "uploads/";
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);
$a = move_uploaded_file($file_loc, $folder . $final_file);
$sql = "UPDATE game_services SET heading='$heading',image='$final_file' WHERE id='$id'";
echo db::query($sql);
}
echo "
<script>
location = 'services.php'
</script>";
}
//game_services
if (isset($_GET['del_game'])) {
$id = $_GET['del_game'];
$sql = "DELETE FROM game_services WHERE id='$id'";
db::query($sql);
echo "
<script>
location = 'services.php'
</script>";
}

//add_courses
if (isset($_POST['add_courses'])) {
$heading = $db->real_escape_string($_POST['heading']);
$dcp = $db->real_escape_string($_POST['dcp']);
$price = $db->real_escape_string($_POST['price']);
$button_name = $db->real_escape_string($_POST['button_name']);

$file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
$file_loc = $_FILES['image']['tmp_name'];
$file_size = $_FILES['image']['size'];
$file_type = $_FILES['image']['type'];
$folder = "uploads/";
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);
$a = move_uploaded_file($file_loc, $folder . $final_file);
$query_insert = "INSERT INTO `courses` (`heading`,`image`,`dcp`,`price`,`button_name`) VALUES
('$heading','$final_file','$dcp','$price','$button_name')";
db::query($query_insert);
echo "
<script>
location = 'courses.php'
</script>";
}

//update_courses
if (isset($_POST['update_courses'])) {
$heading = $db->real_escape_string($_POST['heading']);
$dcp = $db->real_escape_string($_POST['dcp']);
$price = $db->real_escape_string($_POST['price']);
$button_name = $db->real_escape_string($_POST['button_name']);

$id=$_POST['id'];
if ($_FILES['image']['name'] == "") {
$sql = "UPDATE courses SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name' WHERE id='$id'";
db::query($sql);
} else {
$file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
$file_loc = $_FILES['image']['tmp_name'];
$file_size = $_FILES['image']['size'];
$file_type = $_FILES['image']['type'];
$folder = "uploads/";
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);
$a = move_uploaded_file($file_loc, $folder . $final_file);
$sql = "UPDATE courses SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name',image='$final_file'
WHERE id='$id'";
echo db::query($sql);
}
echo "
<script>
location = 'courses.php'
</script>";
}
//del_courses
if (isset($_GET['del_courses'])) {
$id = $_GET['del_courses'];
$sql = "DELETE FROM courses WHERE id='$id'";
db::query($sql);
echo "
<script>
location = 'courses.php'
</script>";
}


//add_testimonials
if (isset($_POST['add_testimonials'])) {
$name = $db->real_escape_string($_POST['name']);
$dcp = $db->real_escape_string($_POST['dcp']);
$designation = $db->real_escape_string($_POST['designation']);

$file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
$file_loc = $_FILES['image']['tmp_name'];
$file_size = $_FILES['image']['size'];
$file_type = $_FILES['image']['type'];
$folder = "uploads/";
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);
$a = move_uploaded_file($file_loc, $folder . $final_file);
$query_insert = "INSERT INTO `testimonials` (`name`,`image`,`dcp`,`designation`) VALUES
('$name','$final_file','$dcp','$designation')";
db::query($query_insert);
echo "
<script>
location = 'testimonials.php'
</script>";
}

//update_testimonials
if (isset($_POST['update_testimonials'])) {
$name = $db->real_escape_string($_POST['name']);
$dcp = $db->real_escape_string($_POST['dcp']);
$designation = $db->real_escape_string($_POST['designation']);

$id=$_POST['id'];
if ($_FILES['image']['name'] == "") {
$sql = "UPDATE testimonials SET name='$name',dcp='$dcp',designation='$designation' WHERE id='$id'";
db::query($sql);
} else {
$file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
$file_loc = $_FILES['image']['tmp_name'];
$file_size = $_FILES['image']['size'];
$file_type = $_FILES['image']['type'];
$folder = "uploads/";
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);
$a = move_uploaded_file($file_loc, $folder . $final_file);
$sql = "UPDATE testimonials SET name='$name',dcp='$dcp',designation='$designation',image='$final_file' WHERE id='$id'";
echo db::query($sql);
}
echo "
<script>
location = 'testimonials.php'
</script>";
}
//del_testimonials
if (isset($_GET['del_testimonials'])) {
$id = $_GET['del_testimonials'];
$sql = "DELETE FROM testimonials WHERE id='$id'";
db::query($sql);
echo "
<script>
location = 'testimonials.php'
</script>";
}

// add_product
if (isset($_POST['add_product'])) {
    $heading = $db->real_escape_string($_POST['heading']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $price = $db->real_escape_string($_POST['price']);
    
    // File upload handling
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
        $query_insert = "INSERT INTO `product`(`heading`, `dcp`, `image`, `price`) VALUES ('$heading',' $dcp','$final_file',' $price')";
        db::query($query_insert);
        echo "
<script>
        location = 'product.php'
        </script>";
}

//update_product
if (isset($_POST['update_product'])) {
    $heading = $db->real_escape_string($_POST['heading']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $price = $db->real_escape_string($_POST['price']);
    $id=$_POST['id'];
    if ($_FILES['image']['name'] == "") {
    $sql = "UPDATE `product` SET `heading`='$heading',`dcp`='$dcp',`price`='$price' WHERE id='$id'";
    db::query($sql);
    } else {
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
    $sql = "UPDATE `product` SET `heading`='$heading',`dcp`='$dcp',,`image`='$final_file',`price`='$price' WHEREid='$id''
    ";
    echo db::query($sql);
    }
    echo "
<script>
    location = 'product.php'
    </script>";
    }

//del_product
if (isset($_GET['del_product'])) {
    $id = $_GET['del_product'];
    $sql = "DELETE FROM `product` WHERE id='$id'";
    db::query($sql);
    echo "
<script>
    location = 'product.php'
    </script>";
    }


//add_review
if (isset($_POST['add_review'])) {
    $heading = $db->real_escape_string($_POST['heading']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $price = $db->real_escape_string($_POST['price']);
    $btn = $db->real_escape_string($_POST['btn']);
    
    // File upload handling
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);

    // Check if file upload was successful before proceeding with the database insertion
    
        $query_insert = "INSERT INTO `review_course`(`heading`, `image`, `dcp`, `btn`,`price`) VALUES ('$heading','$final_file','$dcp','$btn','$price')";
        db::query($query_insert);
        echo "
<script>
        location = 'review_course.php'
        </script>";
}

//update_review
if (isset($_POST['update_review'])) {
$heading = $db->real_escape_string($_POST['heading']);
$dcp = $db->real_escape_string($_POST['dcp']);
$price = $db->real_escape_string($_POST['price']);
$btn = $db->real_escape_string($_POST['btn']);

$id=$_POST['id'];
if ($_FILES['image']['name'] == "") {
$sql = "UPDATE `review_course` SET`heading`='$heading',`dcp`='$dcp',`btn`='$btn',`price`='$price' WHERE id='$id'
";
db::query($sql);
} else {
$file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
$file_loc = $_FILES['image']['tmp_name'];
$file_size = $_FILES['image']['size'];
$file_type = $_FILES['image']['type'];
$folder = "uploads/";
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);
$a = move_uploaded_file($file_loc, $folder . $final_file);
$sql = "UPDATE `review_course` SET`heading`='$heading',`image`='$final_file',`dcp`='$dcp',`btn`='$btn',`price`='$price'
WHERE id='$id'";
echo db::query($sql);
}
echo "
<script>
location = 'review_course.php'
</script>";
}

//del_review
if (isset($_GET['del_review'])) {
$id = $_GET['del_review'];
$sql = "DELETE FROM `review_course` WHERE id='$id'";
db::query($sql);
echo "
<script>
location = 'review_course.php'
</script>";
}

//add_blog
if (isset($_POST['add_blog'])) {
$heading = $db->real_escape_string($_POST['heading']);
$dcp = $db->real_escape_string($_POST['dcp']);

$file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
$file_loc = $_FILES['image']['tmp_name'];
$file_size = $_FILES['image']['size'];
$file_type = $_FILES['image']['type'];
$folder = "uploads/";
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);
$a = move_uploaded_file($file_loc, $folder . $final_file);
$query_insert = "INSERT INTO `blog` (`heading`,`image`,`dcp`) VALUES ('$heading','$final_file','$dcp')";
db::query($query_insert);
echo "
<script>
location = 'blog.php'
</script>";
}

//update_blog
if (isset($_POST['update_blog'])) {
$heading = $db->real_escape_string($_POST['heading']);
$dcp = $db->real_escape_string($_POST['dcp']);

$id=$_POST['id'];
if ($_FILES['image']['name'] == "") {
$sql = "UPDATE blog SET heading='$heading',dcp='$dcp' WHERE id='$id'";
db::query($sql);
} else {
$file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
$file_loc = $_FILES['image']['tmp_name'];
$file_size = $_FILES['image']['size'];
$file_type = $_FILES['image']['type'];
$folder = "uploads/";
$new_file_name = strtolower($file);
$final_file = str_replace(' ', '-', $new_file_name);
$a = move_uploaded_file($file_loc, $folder . $final_file);
$sql = "UPDATE blog SET heading='$heading',dcp='$dcp',image='$final_file' WHERE id='$id'";
echo db::query($sql);
}
echo "
<script>
location = 'blog.php'
</script>";
}
//del_blog
if (isset($_GET['del_blog'])) {
$id = $_GET['del_blog'];
$sql = "DELETE FROM blog WHERE id='$id'";
db::query($sql);
echo "
<script>
location = 'blog.php'
</script>";
}

//add_faq
if (isset($_POST['add_faq'])) {
$question = $db->real_escape_string($_POST['question']);
$answer = $db->real_escape_string($_POST['answer']);
$query_insert = "INSERT INTO `faq` (`question`,`answer`) VALUES ('$question','$answer')";
db::query($query_insert);
echo "
<script>
location = 'faq.php'
</script>";
}

//update_faq
if (isset($_POST['update_faq'])) {
$question = $db->real_escape_string($_POST['question']);
$answer = $db->real_escape_string($_POST['answer']);

$id=$_POST['id'];
$sql = "UPDATE faq SET question='$question',answer='$answer' WHERE id='$id'";
db::query($sql);
echo "
<script>
location = 'faq.php'
</script>";
}
//del_faq
if (isset($_GET['del_faq'])) {
$id = $_GET['del_faq'];
$sql = "DELETE FROM faq WHERE id='$id'";
db::query($sql);
echo "
<script>
location = 'faq.php'
</script>";
}



//add_contact
if (isset($_POST['add_contact'])) {
$name = $db->real_escape_string($_POST['name']);
$subject = $db->real_escape_string($_POST['subject']);
$email = $db->real_escape_string($_POST['email']);
$phone = $db->real_escape_string($_POST['phone']);
$message = $db->real_escape_string($_POST['message']);

$query_insert = "INSERT INTO `contact` (`name`,`subject`,`email`,`phone`,`message`) VALUES
('$name','$subject','$email','$phone','$message')";
db::query($query_insert);
echo "
<script>
location = '../contact.php'
</script>";
}
//del_contact
if (isset($_GET['del_contact'])) {
$id = $_GET['del_contact'];
$sql = "DELETE FROM contact WHERE id='$id'";
db::query($sql);
echo "
<script>
location = 'contact.php'
</script>";
}
// update_contact_detail
if (isset($_POST['update_contact_detail'])) {
$heading = $db->real_escape_string($_POST['heading']);
$dcp = $db->real_escape_string($_POST['dcp']);
$phone = $db->real_escape_string($_POST['phone']);
$email = $db->real_escape_string($_POST['email']);
$location = $db->real_escape_string($_POST['location']);

$id = $db->real_escape_string($_POST['id']);
$sql = "UPDATE contact_detail SET heading='$heading',dcp='$dcp',phone='$phone',email='$email',location='$location'";
db::query($sql);

echo "
<script>
location = 'contact_detail.php'
</script>";
}
//add_newslatter
if (isset($_POST['add_newslatter'])) {
            $email = $db->real_escape_string($_POST['email']);
            $query_insert = "INSERT INTO `newslatter` (`email`) VALUES ('$email')";
            db::query($query_insert);
            echo "
<script>
            location = '../index.php'
            </script>";
            }
            //del_newslatter
            if (isset($_GET['del_newslatter'])) {
            $id = $_GET['del_newslatter'];
            $sql = "DELETE FROM newslatter WHERE id='$id'";
            db::query($sql);
            echo "
<script>
            location = 'newslatter.php'
            </script>";
}


    //update_study
    if (isset($_POST['update_study'])) {
    $heading = $db->real_escape_string($_POST['heading']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $price = $db->real_escape_string($_POST['price']);
    $button_name = $db->real_escape_string($_POST['button_name']);
    
    $id=$_POST['id'];
    if ($_FILES['image']['name'] == "") {
    $sql = "UPDATE courses SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name' WHERE id='$id'";
    db::query($sql);
    } else {
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
    $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name',image='$final_file'
    WHERE id='$id'";
    echo db::query($sql);
    }
    echo "
<script>
    location = 'study_option.php'
    </script>";
    }
    //del_study
    if (isset($_GET['del_study'])) {
    $id = $_GET['del_study'];
    $sql = "DELETE FROM courses WHERE id='$id'";
    db::query($sql);
    echo "
<script>
    location = 'study_option.php'
    </script>";
    }

    //update_resources
    if (isset($_POST['update_resources'])) {
    $heading = $db->real_escape_string($_POST['heading']);
    $dcp = $db->real_escape_string($_POST['dcp']);
    $price = $db->real_escape_string($_POST['price']);
    $button_name = $db->real_escape_string($_POST['button_name']);
    
    $id=$_POST['id'];
    if ($_FILES['image']['name'] == "") {
    $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name' WHERE id='$id'";
    db::query($sql);
    } else {
    $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
    $file_loc = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_type = $_FILES['image']['type'];
    $folder = "uploads/";
    $new_file_name = strtolower($file);
    $final_file = str_replace(' ', '-', $new_file_name);
    $a = move_uploaded_file($file_loc, $folder . $final_file);
    $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name',image='$final_file'
    WHERE id='$id'";
    echo db::query($sql);
    }
    echo "
<script>
    location = 'resources.php'
    </script>";
    }
    //del_resources
    if (isset($_GET['del_resources'])) {
    $id = $_GET['del_resources'];
    $sql = "DELETE FROM `courses` WHERE id='$id'";
    db::query($sql);
    echo "
<script>
    location = 'resources.php'
    </script>";
    }
       
        //update_solution
        if (isset($_POST['update_solution'])) {
        $heading = $db->real_escape_string($_POST['heading']);
        $dcp = $db->real_escape_string($_POST['dcp']);
        $price = $db->real_escape_string($_POST['price']);
        $button_name = $db->real_escape_string($_POST['button_name']);
        
        $id=$_POST['id'];
        if ($_FILES['image']['name'] == "") {
        $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name' WHERE id='$id'";
        db::query($sql);
        } else {
        $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
        $file_loc = $_FILES['image']['tmp_name'];
        $file_size = $_FILES['image']['size'];
        $file_type = $_FILES['image']['type'];
        $folder = "uploads/";
        $new_file_name = strtolower($file);
        $final_file = str_replace(' ', '-', $new_file_name);
        $a = move_uploaded_file($file_loc, $folder . $final_file);
        $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name',image='$final_file'
        WHERE id='$id'";
        echo db::query($sql);
        }
        echo "
<script>
        location = 'solution.php'
        </script>";
        }
        //del_solution
        if (isset($_GET['del_solution'])) {
        $id = $_GET['del_solution'];
        $sql = "DELETE FROM `courses` WHERE id='$id'";
        db::query($sql);
        echo "
<script>
        location = 'solution.php'
        </script>";
        }       
            //update_ancc_exam
            if (isset($_POST['update_ancc_exam'])) {
            $heading = $db->real_escape_string($_POST['heading']);
            $dcp = $db->real_escape_string($_POST['dcp']);
            $price = $db->real_escape_string($_POST['price']);
            $button_name = $db->real_escape_string($_POST['button_name']);
            
            $id=$_POST['id'];
            if ($_FILES['image']['name'] == "") {
            $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name' WHERE id='$id'";
            db::query($sql);
            } else {
            $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
            $file_loc = $_FILES['image']['tmp_name'];
            $file_size = $_FILES['image']['size'];
            $file_type = $_FILES['image']['type'];
            $folder = "uploads/";
            $new_file_name = strtolower($file);
            $final_file = str_replace(' ', '-', $new_file_name);
            $a = move_uploaded_file($file_loc, $folder . $final_file);
            $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name',image='$final_file'
            WHERE id='$id'";
            echo db::query($sql);
            }
            echo "
<script>
            location = 'ancc_exam.php'
            </script>";
            }
            //del_ancc_exam
            if (isset($_GET['del_ancc_exam'])) {
            $id = $_GET['del_ancc_exam'];
            $sql = "DELETE FROM `courses` WHERE id='$id'";
            db::query($sql);
            echo "
<script>
            location = 'ancc_exam.php'
            </script>";
            }





            //update_review_course
            if (isset($_POST['update_review_course'])) {
                $heading = $db->real_escape_string($_POST['heading']);
                $dcp = $db->real_escape_string($_POST['dcp']);
                $price = $db->real_escape_string($_POST['price']);
                $button_name = $db->real_escape_string($_POST['button_name']);
                
                $id=$_POST['id'];
                if ($_FILES['image']['name'] == "") {
                $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name' WHERE id='$id'";
                db::query($sql);
                } else {
                $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
                $file_loc = $_FILES['image']['tmp_name'];
                $file_size = $_FILES['image']['size'];
                $file_type = $_FILES['image']['type'];
                $folder = "uploads/";
                $new_file_name = strtolower($file);
                $final_file = str_replace(' ', '-', $new_file_name);
                $a = move_uploaded_file($file_loc, $folder . $final_file);
                $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name',image='$final_file'
                WHERE id='$id'";
                echo db::query($sql);
                }
                echo "
<script>
                location = 'review_course.php'
                </script>";
                }
                //del_review_course
                if (isset($_GET['del_review_course'])) {
                $id = $_GET['del_review_course'];
                $sql = "DELETE FROM `courses` WHERE id='$id'";
                db::query($sql);
                echo "
<script>
                location = 'review_course.php'
                </script>";
                }
                 //update_crash_course
            if (isset($_POST['update_crash_course'])) {
                $heading = $db->real_escape_string($_POST['heading']);
                $dcp = $db->real_escape_string($_POST['dcp']);
                $price = $db->real_escape_string($_POST['price']);
                $button_name = $db->real_escape_string($_POST['button_name']);
                
                $id=$_POST['id'];
                if ($_FILES['image']['name'] == "") {
                $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name' WHERE id='$id'";
                db::query($sql);
                } else {
                $file = rand(1000, 100000) . "-" . $_FILES['image']['name'];
                $file_loc = $_FILES['image']['tmp_name'];
                $file_size = $_FILES['image']['size'];
                $file_type = $_FILES['image']['type'];
                $folder = "uploads/";
                $new_file_name = strtolower($file);
                $final_file = str_replace(' ', '-', $new_file_name);
                $a = move_uploaded_file($file_loc, $folder . $final_file);
                $sql = "UPDATE `courses` SET heading='$heading',dcp='$dcp',price='$price',button_name='$button_name',image='$final_file'
                WHERE id='$id'";
                echo db::query($sql);
                }
                echo "
<script>
                location = 'crash_course.php'
                </script>";
                }
                //del_review_course
                if (isset($_GET['del_crash_course'])) {
                $id = $_GET['del_crash_course'];
                $sql = "DELETE FROM `courses` WHERE id='$id'";
                db::query($sql);
                echo "
<script>
                location = 'crash_course.php'
                </script>";
                }
                
                //del_user
if (isset($_GET['del_user'])) {
$id = $_GET['del_user'];
$sql = "DELETE FROM users WHERE id='$id'";
db::query($sql);
echo "
<script>
location = 'user.php'
</script>";
}