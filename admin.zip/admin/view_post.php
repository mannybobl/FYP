<?php
require_once("header.php");
require_once("sidebar.php");

$id=$_GET['id'];
$data="SELECT * FROM game_post WHERE user_id='$id'";
$recs=db::getRecords($data);

?>

<!-- main content start -->
<div class="main-content">
	<div class="row mb-5">
		<div class="col-md-12">
			<div class="card" style="background:#4b91f0;">
				<div class="card-body">
					<div class="row">
						<div class="col-md-6">
							<h4 class="mb-0 text-dark">View Game Post</h4>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	 <div class="col-12">
            <div class="card" style="background: #fff;">
                <div class="card-body">
                    <table class="table table-bordered table-dashed table-hover digi-dataTable dataTable-resize table-striped" id="componentDataTable3">
                        <thead>
                            <tr>
                                <th><span class="resize-col">ID</span></th>
                                <th><span class="resize-col">person_need</span></th>
                                <th><span class="resize-col">post_name</span></th>
                                <th><span class="resize-col">date</span></th>
                                <th><span class="resize-col">time</span></th>
                                <th><span class="resize-col">APPLIED USER</span></th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
		if($recs)
		{
			foreach($recs as $rec)
			{
				?>
                                    <tr>
                                        <td><span class="resize-col"><?php  echo $rec['id'] ?></span></td>
                                        <td><span class="resize-col"><?php  echo $rec['person_need'] ?></span></td>
                                        <td><span class="resize-col"><?php  echo $rec['post_name'] ?></span></td>
                                        <td><span class="resize-col"><?php  echo $rec['date'] ?></span></td>
                                        <td><span class="resize-col"><?php  echo $rec['time'] ?></span></td>
                                      <td><span class="resize-col">
                                            <a href="applied_user.php?id=<?php  echo $rec['id']; ?>" class="btn  btn-primary text-light" style="text-decoration: none;">APPLIED USER</a>
                                        </span></td>
                                    </tr>
                                    <?php
			}
		}
		?>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>

	<?php
	require_once("footer.php")
?>